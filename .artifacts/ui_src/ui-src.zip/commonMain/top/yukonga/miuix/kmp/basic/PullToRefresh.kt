// Copyright 2025, compose-miuix-ui contributors
// SPDX-License-Identifier: Apache-2.0

package top.yukonga.miuix.kmp.basic

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.IntrinsicMeasurable
import androidx.compose.ui.layout.IntrinsicMeasureScope
import androidx.compose.ui.layout.LayoutModifier
import androidx.compose.ui.layout.Measurable
import androidx.compose.ui.layout.MeasureResult
import androidx.compose.ui.layout.MeasureScope
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.constrain
import androidx.compose.ui.unit.constrainHeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.isSpecified
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.fastAny
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.utils.LocalOverScrollState
import top.yukonga.miuix.kmp.utils.OverScrollState
import top.yukonga.miuix.kmp.utils.SpringEngine
import top.yukonga.miuix.kmp.utils.SpringMath
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import kotlin.math.sin

/**
 * A container that supports the "pull-to-refresh" gesture.
 *
 * This composable follows a hoisted state pattern, where the logical `isRefreshing` state
 * is managed by the caller (e.g., a ViewModel). It coordinates nested scrolling to enable a
 * pull-to-refresh action, displays a customizable indicator, and triggers a callback when a
 * refresh is requested.
 *
 * @param isRefreshing A boolean state representing whether a refresh is currently in progress.
 * This state should be hoisted and is the source of truth for the refresh operation, in both
 * directions: raising it to `true` while the indicator is idle shows the indicator
 * programmatically (e.g. refresh-on-entry), and lowering it to `false` ends the refresh. If it
 * is `false` when the indicator settles into its refreshing state — because it was never
 * raised, or was raised and lowered again before the next frame — the refresh is treated as
 * already finished and the completion animation runs immediately; a `true` that arrives later
 * shows the indicator again.
 * @param onRefresh A lambda to be invoked when a refresh is triggered by the user. This lambda
 * should initiate the data loading, set `isRefreshing` to `true`, and is responsible for
 * eventually setting it back to `false` upon completion. It is not invoked when the indicator
 * settles while `isRefreshing` is already `true`; the gesture joins the refresh in progress.
 * @param modifier The modifier to be applied to this container.
 * @param pullToRefreshState The state object that manages the UI and animations of the indicator.
 * See [rememberPullToRefreshState].
 * @param contentPadding The padding to be applied to the content. The top padding is used to
 * correctly offset the refresh indicator.
 * @param topAppBarScrollBehavior An optional [ScrollBehavior] for a `TopAppBar` to coordinate
 * scrolling between the app bar and the pull-to-refresh gesture.
 * @param color The color of the refresh indicator.
 * @param circleSize The size of the refresh indicator's animated circle.
 * @param refreshTexts A list of strings representing the text shown in different states.
 * @param refreshTextStyle The [TextStyle] for the refresh indicator text.
 * @param onPullProgress A callback that observes [PullToRefreshState.fullDragProgress]: the drag
 * progress across the full visual range from 0.0 to 1.0 (where 1.0 represents the maximum
 * stretch distance). Unlike threshold-relative progress, this value continues to increase when
 * the user pulls beyond the threshold. Invoked once with the current value on composition, then
 * on every change — whether driven by a pull gesture or by the programmatic expansion and
 * completion animations. Useful for external components that need to react to pull depth in
 * real time.
 * @param content The content to be displayed inside the container.
 */
@Composable
fun PullToRefresh(
    isRefreshing: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    pullToRefreshState: PullToRefreshState = rememberPullToRefreshState(),
    contentPadding: PaddingValues = PaddingValues(0.dp),
    topAppBarScrollBehavior: ScrollBehavior? = null,
    color: Color = PullToRefreshDefaults.color,
    circleSize: Dp = PullToRefreshDefaults.circleSize,
    refreshTexts: List<String> = PullToRefreshDefaults.refreshTexts,
    refreshTextStyle: TextStyle = PullToRefreshDefaults.refreshTextStyle,
    onPullProgress: ((Float) -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    val coroutineScope = rememberCoroutineScope()
    val overScrollState = LocalOverScrollState.current
    val currentOnRefresh by rememberUpdatedState(onRefresh)
    val currentIsRefreshing by rememberUpdatedState(isRefreshing)
    // Level reader for long-lived closures; capturing the raw Boolean would freeze it.
    val isRefreshingNow: () -> Boolean = remember { { currentIsRefreshing } }

    // Reified callback reference that stays current without re-keying the LaunchedEffect.
    val currentOnPullProgress by rememberUpdatedState(onPullProgress)

    // Emit fullDragProgress changes to the callback, coalesced per frame via snapshotFlow.
    LaunchedEffect(pullToRefreshState) {
        snapshotFlow { pullToRefreshState.fullDragProgress }
            .collect { progress ->
                currentOnPullProgress?.invoke(progress)
            }
    }

    // Two-way level sync with the hoisted isRefreshing. refreshState is a key on purpose:
    // entering Refreshing re-samples the level, so a sub-frame true->false pulse cannot latch.
    LaunchedEffect(isRefreshing, pullToRefreshState.refreshState) {
        if (!isRefreshing && pullToRefreshState.refreshState == RefreshState.Refreshing) {
            // Independent job: the Refreshing -> RefreshComplete re-key would cancel a direct
            // suspend call mid completion animation.
            coroutineScope.launch {
                pullToRefreshState.finishRefreshing(isRefreshingNow)
            }
        } else if (isRefreshing && pullToRefreshState.refreshState == RefreshState.Idle) {
            // Rising edge while idle: show the indicator programmatically.
            coroutineScope.launch {
                pullToRefreshState.showRefreshing(isRefreshingNow)
            }
        }
    }

    // This connection establishes the chain of responsibility for nested scroll events.
    val nestedScrollConnection =
        remember(pullToRefreshState, topAppBarScrollBehavior, overScrollState) {
            // Reset cached connection when dependencies change
            pullToRefreshState.cachedNestedScrollConnection = null
            createPullToRefreshConnection(
                pullToRefreshState,
                topAppBarScrollBehavior,
                overScrollState,
            )
        }

    // Press/pan gesture session: the pull engages and resolves only inside one. Scroll events
    // never alter it (wheel has no release signal); mouse presses never open it (a mouse press
    // cannot drag a scrollable).
    val pointerModifier = remember(pullToRefreshState) {
        pullToRefreshState.isGestureActive = false
        Modifier.pointerInput(pullToRefreshState) {
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent()
                    val active = when (event.type) {
                        PointerEventType.PanStart, PointerEventType.PanMove -> true
                        PointerEventType.PanEnd -> false
                        PointerEventType.Scroll -> pullToRefreshState.isGestureActive
                        else -> event.changes.fastAny { it.pressed && it.type != PointerType.Mouse }
                    }
                    if (pullToRefreshState.isGestureActive != active) {
                        pullToRefreshState.isGestureActive = active
                        if (
                            !active &&
                            (pullToRefreshState.refreshState == RefreshState.Pulling || pullToRefreshState.refreshState == RefreshState.ThresholdReached)
                        ) {
                            coroutineScope.launch {
                                pullToRefreshState.handlePointerRelease(currentOnRefresh, isRefreshingNow)
                            }
                        }
                    }
                }
            }
        }
    }

    CompositionLocalProvider(
        LocalPullToRefreshState provides pullToRefreshState,
    ) {
        val boxModifier = remember(modifier, nestedScrollConnection, pointerModifier) {
            modifier
                .nestedScroll(nestedScrollConnection)
                .then(pointerModifier)
        }

        Box(modifier = boxModifier) {
            Column {
                RefreshHeader(
                    pullToRefreshState = pullToRefreshState,
                    circleSize = circleSize,
                    color = color,
                    refreshTexts = refreshTexts,
                    refreshTextStyle = refreshTextStyle,
                    modifier = Modifier.offset(y = contentPadding.calculateTopPadding()),
                )
                content()
            }
        }
    }
}

/**
 * Creates and remembers a [PullToRefreshState] across recompositions.
 *
 * This state object is responsible for managing the visual aspects of the refresh indicator,
 * such as its position and animation. The logical `isRefreshing` state should be hoisted and
 * managed separately.
 *
 * @param refreshThreshold An optional pull progress threshold (0.0 ~ 1.0)
 * representing the percentage of the full damped drag range required to trigger refresh.
 * Default is 0.25 (25%). Lower values make refresh easier to trigger; higher values
 * require a deeper pull. 0.0 triggers on any pull, however small.
 * @return A remembered instance of [PullToRefreshState].
 */
@Composable
fun rememberPullToRefreshState(
    refreshThreshold: Float = 0.25f,
): PullToRefreshState {
    val coroutineScope = rememberCoroutineScope()

    // The state object is created using `remember` as it's a runtime UI state manager.
    // The logical `isRefreshing` state, which survives process death, is hoisted.
    val state = remember {
        PullToRefreshState(coroutineScope)
    }

    // Update context-dependent properties on the state instance to ensure it's always current.
    val windowInfo = LocalWindowInfo.current
    state.maxDragDistancePx = windowInfo.containerSize.height.toFloat()
    // The largest dragOffset a full-window finger travel can produce under SpringMath damping.
    state.fullDragRangePx = SpringMath.obtainDampingDistance(1f, state.maxDragDistancePx)
    state.refreshThreshold = refreshThreshold.coerceIn(0f, 1f)
    state.triggerProgressOffset = state.refreshThreshold * state.fullDragRangePx
    state.refreshThresholdOffset = windowInfo.containerSize.height.toFloat() * MAX_DRAWRATIO * THRESHOLD_RADIO

    SideEffect {
        // Re-glue a settled indicator when the threshold changes mid-refresh (window resize, or
        // a show that ran before first measure): Refreshing visuals scale with visualProgress.
        val target = state.refreshThresholdOffset
        if (state.refreshState == RefreshState.Refreshing &&
            state.animationJob == null &&
            state.dragOffset != target
        ) {
            state.dragOffset = target
            state.currentTouch = SpringMath.obtainTouchDistance(target, state.maxDragDistancePx)
        }
    }

    return state
}

/** Represents the various visual states of the pull-to-refresh indicator. */
sealed interface RefreshState {
    data object Idle : RefreshState
    data object Pulling : RefreshState
    data object ThresholdReached : RefreshState
    data object Refreshing : RefreshState
    data object RefreshComplete : RefreshState
}

/**
 * A UI state holder for the [PullToRefresh] composable.
 *
 * This class manages the internal state machine for animations and nested scroll interactions,
 * driven by the hoisted `isRefreshing` boolean.
 *
 * @param coroutineScope A [CoroutineScope] used to launch animations and state updates.
 */
class PullToRefreshState(
    internal var coroutineScope: CoroutineScope,
) {
    internal var maxDragDistancePx: Float = 0f
    internal var fullDragRangePx: Float = 0f
    internal var refreshThresholdOffset: Float = 0f
    internal var triggerProgressOffset: Float = 0f

    /** The larger of the built-in visual threshold and the user-configured trigger threshold;
     * the denominator of [pullProgress]. */
    internal val effectiveThresholdOffset: Float
        get() = max(refreshThresholdOffset, triggerProgressOffset)

    /** The pull progress threshold (0.0~1.0) at which a refresh is triggered, relative to the
     * full damped drag range. Configured through [rememberPullToRefreshState]. */
    var refreshThreshold: Float = 0f
        internal set

    /** The drag offset in pixels. */
    var dragOffset by mutableFloatStateOf(0f)

    /** Cached NestedScrollConnection to avoid creating new instances on every scroll event. */
    var cachedNestedScrollConnection: NestedScrollConnection? = null

    private var internalRefreshState by mutableStateOf<RefreshState>(RefreshState.Idle)

    /** The current visual [RefreshState] of the component. */
    val refreshState: RefreshState get() = internalRefreshState

    /** The progress of the pull gesture, from 0.0 to 1.0, relative to the effective threshold
     * (the larger of the visual threshold and the trigger threshold). With a trigger threshold
     * below the visual threshold, [RefreshState.ThresholdReached] occurs before this reaches 1.0. */
    val pullProgress: Float by derivedStateOf {
        if (effectiveThresholdOffset > 0f) {
            (dragOffset / effectiveThresholdOffset).coerceIn(0f, 1f)
        } else {
            0f
        }
    }

    /** The progress of the pull gesture across the entire damped drag range,
     * from 0.0 to 1.0 (where 1.0 represents the visual maximum).
     * Unlike [pullProgress] which saturates at 1.0 once the threshold is reached,
     * this value continues to grow as the user pulls further beyond the threshold. */
    val fullDragProgress: Float by derivedStateOf {
        if (fullDragRangePx > 0f) {
            (dragOffset / fullDragRangePx).coerceIn(0f, 1f)
        } else {
            0f
        }
    }

    /** The visual scaling progress of the indicator, from 0.0 to 1.0. The scale-up completes
     * at the smaller of the built-in visual threshold and the trigger threshold, so entering
     * [RefreshState.ThresholdReached] always coincides with a fully scaled indicator. */
    val visualProgress: Float by derivedStateOf {
        val scaleEndOffset = min(refreshThresholdOffset, triggerProgressOffset)
        when {
            scaleEndOffset > 0f -> (dragOffset / scaleEndOffset).coerceIn(0f, 1f)

            // A zero trigger threshold means any pull is already past the threshold.
            dragOffset > 0f -> 1f

            else -> 0f
        }
    }

    internal var currentTouch by mutableFloatStateOf(0f)

    internal var isRefreshing by mutableStateOf(false)
    internal var isTouching by mutableStateOf(false)

    /** True while a press or pan gesture session is in flight; wheel events never set it. */
    internal var isGestureActive = false
    internal var isRebounding by mutableStateOf(false)
    private var isProcessingRelease = false
    private val refreshCompleteAnimProgressState = mutableFloatStateOf(1f)
    internal val refreshCompleteAnimProgress: Float get() = refreshCompleteAnimProgressState.floatValue

    // Physics Engine for rebound
    private val springEngine = SpringEngine()
    internal var animationJob: Job? = null

    /**
     * Drives the dragOffset using SpringEngine physics.
     * Runs the animation loop directly in the caller's coroutine context,
     * so cancellation of the caller naturally stops the animation.
     */
    internal suspend fun animateToSpring(targetValue: Float) {
        animationJob?.cancel()

        springEngine.start(
            startValue = dragOffset,
            targetValue = targetValue,
            initialVel = 0f,
        )

        val currentJob = currentCoroutineContext()[Job]
        animationJob = currentJob

        var lastFrameTimeNanos = -1L
        var isFinished = false

        try {
            while (currentCoroutineContext().isActive) {
                isFinished = withFrameNanos { frameTimeNanos ->
                    if (lastFrameTimeNanos == -1L) {
                        lastFrameTimeNanos = frameTimeNanos
                        return@withFrameNanos false
                    }
                    val dt = (frameTimeNanos - lastFrameTimeNanos) / 1_000_000_000f
                    lastFrameTimeNanos = frameTimeNanos

                    val finished = springEngine.step(dt)
                    val newOffset = springEngine.currentPos.toFloat()

                    // Directly update the state
                    dragOffset = newOffset

                    // Crucial: Update currentTouch using inverse damping so that if user catches
                    // the list mid-animation, the touch tracking is consistent with visual position.
                    currentTouch = SpringMath.obtainTouchDistance(newOffset, maxDragDistancePx)

                    finished
                }
                if (isFinished) break
            }
        } finally {
            if (animationJob == currentJob) animationJob = null
            if (isFinished) {
                // Ensure we land exactly on target after normal completion
                dragOffset = targetValue
                currentTouch = SpringMath.obtainTouchDistance(targetValue, maxDragDistancePx)
            }
        }
    }

    /**
     * Enter the refresh queue
     */
    internal suspend fun startRefreshing(onRefresh: () -> Unit, isRefreshingNow: () -> Boolean) {
        if (!isRefreshing) {
            isRefreshing = true
            try {
                // Use spring to move to threshold
                animateToSpring(refreshThresholdOffset)
            } finally {
                if (!isTouching) {
                    // Refreshing must be written before onRefresh(): the sync effect keys on this
                    // change to re-sample the level; reordering re-opens the lost-pulse latch.
                    internalRefreshState = RefreshState.Refreshing
                    // Already true: join the refresh in progress instead of firing a duplicate.
                    if (!isRefreshingNow()) onRefresh()
                } else {
                    isRefreshing = false
                }
            }
        }
    }

    /** Programmatically expands the indicator when the hoisted level turns true while idle. */
    internal suspend fun showRefreshing(isRefreshingNow: () -> Boolean) {
        // Re-check at run time: the launching effect may be stale (rapid toggle around Idle).
        if (isRefreshing || internalRefreshState != RefreshState.Idle || !isRefreshingNow()) return
        isRefreshing = true
        // Refreshing consumes all nested scroll, so the expansion cannot be caught mid-flight.
        internalRefreshState = RefreshState.Refreshing
        animateToSpring(refreshThresholdOffset)
        // Chase a threshold that moved while the spring ran. Covers a show on the mount frame:
        // the window has not reported its size yet, so the first spring settles at a threshold
        // of 0 (invisible indicator), and the SideEffect re-glue skips while animationJob is
        // set — without this loop the indicator would stay invisible for the whole refresh.
        while (internalRefreshState == RefreshState.Refreshing && dragOffset != refreshThresholdOffset) {
            animateToSpring(refreshThresholdOffset)
        }
    }

    /**
     * Called when the hoisted `isRefreshing` state becomes false.
     * Triggers the completion animation and resets the state.
     */
    internal suspend fun finishRefreshing(isRefreshingNow: () -> Boolean) {
        // Re-check at run time: a re-raised level keeps the spinner; the next falling edge retries.
        if (isRefreshing && !isRefreshingNow()) {
            // Stop a running programmatic expansion; the completion animation picks dragOffset
            // up from wherever the cancelled spring left it (height-continuous handoff).
            animationJob?.cancel()
            // Cleared before the first suspension so queued duplicates no-op on the guard above.
            isRefreshing = false
            internalRefreshState = RefreshState.RefreshComplete
            startManualRefreshCompleteAnimation()
        }
    }

    /** Handles the pointer release event to either trigger a refresh or rebound the indicator. */
    internal suspend fun handlePointerRelease(onRefresh: () -> Unit, isRefreshingNow: () -> Boolean) {
        if (isProcessingRelease || isRefreshing || isRebounding) return
        // Cleared only by the launch that owns the release: a release racing an in-flight rebound
        // early-returns above, and a pre-guard clear would erase a catch's isTouching and fire onRefresh.
        isTouching = false
        isProcessingRelease = true
        try {
            if (dragOffset > 0f && dragOffset >= triggerProgressOffset) {
                // If pulled past threshold, will then call startRefreshing().
                startRefreshing(onRefresh, isRefreshingNow)
            } else {
                // If not pulled past threshold, rebound to the resting state using spring.
                try {
                    isRebounding = true
                    animateToSpring(0f)
                } finally {
                    isRebounding = false
                    // Never write Idle under a live touch: a pending show would hijack the gesture.
                    if (!isTouching) resetToIdle()
                }
            }
        } finally {
            isProcessingRelease = false
        }
    }

    private suspend fun startManualRefreshCompleteAnimation() {
        // Height-continuous handoff when completing mid-expansion; 0 once settled at the
        // threshold. Must be the exact inverse of the drive formula below so the first frame
        // re-derives the dragOffset the cancelled spring left behind.
        val initialProgress = if (refreshThresholdOffset > 0f) {
            1f - (dragOffset / refreshThresholdOffset).coerceIn(0f, 1f)
        } else {
            1f
        }
        refreshCompleteAnimProgressState.floatValue = initialProgress
        val animatedValue = Animatable(initialProgress)
        animatedValue.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 200, easing = CubicBezierEasing(0f, 0f, 0f, 0.37f)),
        ) {
            refreshCompleteAnimProgressState.floatValue = this.value
            // Drive dragOffset so indicatorHeight tracks the continuous else formula
            dragOffset = refreshThresholdOffset * (1f - this.value)
            currentTouch = SpringMath.obtainTouchDistance(dragOffset, maxDragDistancePx)
        }
        internalRefreshState = RefreshState.Idle
    }

    /** Resets the refresh state to [RefreshState.Idle]. */
    internal fun resetToIdle() {
        if (internalRefreshState != RefreshState.Refreshing && internalRefreshState != RefreshState.RefreshComplete) {
            internalRefreshState = RefreshState.Idle
        }
    }

    internal fun canPullDown(availableY: Float, source: NestedScrollSource): Boolean = source == NestedScrollSource.UserInput && isGestureActive && availableY > 0f

    /** Creates a [NestedScrollConnection] for the pull-to-refresh logic itself. */
    internal fun getOrCreateNestedScrollConnection(
        overScrollState: OverScrollState,
    ): NestedScrollConnection {
        // Return cached instance if already created to avoid allocations during scrolling
        cachedNestedScrollConnection?.let { return it }

        return (
            object : NestedScrollConnection {
                private fun applyDrag(delta: Float) {
                    if (delta == 0f) return
                    currentTouch += delta
                    currentTouch = currentTouch.coerceIn(-maxDragDistancePx, maxDragDistancePx)

                    val normalized = min(abs(currentTouch) / maxDragDistancePx, 1.0f)
                    val dampedDist = SpringMath.obtainDampingDistance(normalized, maxDragDistancePx)
                    dragOffset = sign(currentTouch) * dampedDist

                    when {
                        dragOffset > 0f && dragOffset >= triggerProgressOffset -> RefreshState.ThresholdReached
                        dragOffset > 0 -> RefreshState.Pulling
                        else -> RefreshState.Idle
                    }.also { nextState ->
                        if (refreshState != nextState) {
                            internalRefreshState = nextState
                        }
                    }
                }

                override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                    // Only defer to overscroll when refresh is idle.
                    if (overScrollState.isOverScrollActive && refreshState == RefreshState.Idle) return Offset.Zero
                    // If the refresh is in progress, consume all scroll events.
                    if (refreshState == RefreshState.Refreshing || refreshState == RefreshState.RefreshComplete) {
                        return available
                    }

                    // When pulling up while the indicator is visible, consume the scroll to hide it.
                    if (source == NestedScrollSource.UserInput && isGestureActive && available.y < 0 && (dragOffset > 0f || currentTouch > 0f)) {
                        isTouching = true
                        animationJob?.cancel()
                        applyDrag(available.y)
                        return Offset(0f, available.y)
                    }
                    return Offset.Zero
                }

                override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                    // If the refresh is in progress, consume all scroll events.
                    if (refreshState == RefreshState.Refreshing || refreshState == RefreshState.RefreshComplete) {
                        return available
                    }

                    // When pulling down after the content is at its top, consume the scroll to show the indicator.
                    if (canPullDown(available.y, source)) {
                        isTouching = true
                        animationJob?.cancel()
                        applyDrag(available.y)
                        return Offset(0f, available.y)
                    }
                    return Offset.Zero
                }
            }
            ).also { cachedNestedScrollConnection = it }
    }
}

/**
 * A factory function to create the main [NestedScrollConnection] for the [PullToRefresh] component.
 */
private fun createPullToRefreshConnection(
    pullToRefreshState: PullToRefreshState,
    topAppBarScrollBehavior: ScrollBehavior?,
    overScrollState: OverScrollState,
): NestedScrollConnection = object : NestedScrollConnection {
    override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
        when (pullToRefreshState.refreshState) {
            RefreshState.Idle -> {
                val consumedByAppBar = topAppBarScrollBehavior?.nestedScrollConnection?.onPreScroll(available, source) ?: Offset.Zero
                val remaining = available - consumedByAppBar
                val consumedByRefresh = pullToRefreshState
                    .getOrCreateNestedScrollConnection(overScrollState)
                    .onPreScroll(remaining, source)
                return consumedByAppBar + consumedByRefresh
            }

            RefreshState.RefreshComplete, RefreshState.Refreshing -> {
                return available
            }

            else -> {
                val consumedByRefresh = pullToRefreshState.getOrCreateNestedScrollConnection(overScrollState).onPreScroll(available, source)
                val remaining = available - consumedByRefresh
                val consumedByAppBar = topAppBarScrollBehavior?.nestedScrollConnection?.onPreScroll(remaining, source) ?: Offset.Zero
                return consumedByRefresh + consumedByAppBar
            }
        }
    }

    override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
        when (pullToRefreshState.refreshState) {
            RefreshState.RefreshComplete, RefreshState.Refreshing -> {
                return available
            }

            else -> {
                val consumedByAppBar =
                    topAppBarScrollBehavior?.nestedScrollConnection?.onPostScroll(consumed, available, source) ?: Offset.Zero
                val remaining = available - consumedByAppBar
                val consumedByRefresh = pullToRefreshState
                    .getOrCreateNestedScrollConnection(overScrollState)
                    .onPostScroll(consumed, remaining, source)
                return consumedByAppBar + consumedByRefresh
            }
        }
    }

    override suspend fun onPreFling(available: Velocity): Velocity {
        if (pullToRefreshState.refreshState != RefreshState.Idle) {
            return available
        }
        return Velocity.Zero
    }

    override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
        if (pullToRefreshState.refreshState != RefreshState.Idle) {
            // Ensure the indicator cancels and rebounds to zero.
            if (
                pullToRefreshState.refreshState != RefreshState.Refreshing &&
                pullToRefreshState.refreshState != RefreshState.RefreshComplete &&
                !pullToRefreshState.isRefreshing &&
                !pullToRefreshState.isRebounding &&
                pullToRefreshState.dragOffset > 0f &&
                pullToRefreshState.dragOffset < pullToRefreshState.triggerProgressOffset
            ) {
                try {
                    pullToRefreshState.isRebounding = true
                    pullToRefreshState.animateToSpring(0f)
                } finally {
                    pullToRefreshState.isRebounding = false
                    // Never write Idle under a live touch: a pending show would hijack the gesture.
                    if (!pullToRefreshState.isTouching) pullToRefreshState.resetToIdle()
                }
            }
            return available
        }
        return topAppBarScrollBehavior?.nestedScrollConnection?.onPostFling(consumed, available) ?: Velocity.Zero
    }
}

@Composable
private fun RefreshHeader(
    pullToRefreshState: PullToRefreshState,
    circleSize: Dp,
    color: Color,
    refreshTexts: List<String>,
    refreshTextStyle: TextStyle,
    modifier: Modifier = Modifier,
) {
    val hapticFeedback = LocalHapticFeedback.current

    LaunchedEffect(pullToRefreshState.refreshState) {
        if (pullToRefreshState.refreshState == RefreshState.ThresholdReached) {
            hapticFeedback.performHapticFeedback(HapticFeedbackType.GestureThresholdActivate)
        }
    }

    val refreshText by remember(pullToRefreshState, refreshTexts) {
        derivedStateOf {
            when (pullToRefreshState.refreshState) {
                RefreshState.Idle -> ""

                RefreshState.Pulling -> {
                    if (pullToRefreshState.visualProgress > 0.5) refreshTexts.getOrElse(0) { "" } else ""
                }

                RefreshState.ThresholdReached -> refreshTexts.getOrElse(1) { "" }

                RefreshState.Refreshing -> refreshTexts.getOrElse(2) { "" }

                RefreshState.RefreshComplete -> refreshTexts.getOrElse(3) { "" }
            }
        }
    }

    val refreshTextAlpha by remember(pullToRefreshState) {
        derivedStateOf {
            when (pullToRefreshState.refreshState) {
                RefreshState.Idle -> 0f

                RefreshState.Pulling -> {
                    val progress = pullToRefreshState.visualProgress
                    if (progress > 0.6f) (progress - 0.5f) * 2f else 0f
                }

                RefreshState.ThresholdReached -> 1f

                // visualProgress is 1 from a gesture; it ramps 0->1 only during a programmatic expansion.
                RefreshState.Refreshing -> ((pullToRefreshState.visualProgress - 0.5f) * 2f).coerceIn(0f, 1f)

                RefreshState.RefreshComplete -> {
                    1f - pullToRefreshState.refreshCompleteAnimProgress
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .then(RefreshHeightModifier(pullToRefreshState, circleSize + 36.dp)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top,
    ) {
        RefreshIndicator(
            pullToRefreshState = pullToRefreshState,
            circleSize = circleSize,
            color = color,
            modifier = Modifier.then(RefreshHeightModifier(pullToRefreshState, circleSize)),
        )
        Text(
            text = refreshText,
            style = refreshTextStyle,
            color = color,
            modifier = Modifier.padding(top = 6.dp).graphicsLayer { alpha = refreshTextAlpha },
        )
    }
}

/** Applies the animated height during measurement, retaining height(Dp) constraint and intrinsic behavior. */
private data class RefreshHeightModifier(
    val state: PullToRefreshState,
    val baseHeight: Dp,
) : LayoutModifier {
    private val Density.targetConstraints: Constraints
        get() {
            val height = if (state.refreshState == RefreshState.Idle) {
                0.dp
            } else {
                val stretchExtraDp = (state.dragOffset - state.refreshThresholdOffset).toDp()
                if (stretchExtraDp <= 0.dp) {
                    baseHeight * state.visualProgress
                } else {
                    baseHeight + stretchExtraDp
                }
            }
            val maxHeight = if (height.isSpecified) height.roundToPx().coerceAtLeast(0) else Constraints.Infinity
            val minHeight = if (maxHeight == Constraints.Infinity) 0 else maxHeight
            return Constraints(minHeight = minHeight, maxHeight = maxHeight)
        }

    override fun MeasureScope.measure(measurable: Measurable, constraints: Constraints): MeasureResult {
        val placeable = measurable.measure(constraints.constrain(targetConstraints))
        return layout(placeable.width, placeable.height) { placeable.placeRelative(0, 0) }
    }

    override fun IntrinsicMeasureScope.minIntrinsicWidth(measurable: IntrinsicMeasurable, height: Int): Int = measurable.minIntrinsicWidth(height).coerceAtLeast(0)

    override fun IntrinsicMeasureScope.maxIntrinsicWidth(measurable: IntrinsicMeasurable, height: Int): Int = measurable.maxIntrinsicWidth(height).coerceAtLeast(0)

    override fun IntrinsicMeasureScope.minIntrinsicHeight(measurable: IntrinsicMeasurable, width: Int): Int {
        val constraints = targetConstraints
        return if (constraints.hasFixedHeight) constraints.maxHeight else constraints.constrainHeight(measurable.minIntrinsicHeight(width))
    }

    override fun IntrinsicMeasureScope.maxIntrinsicHeight(measurable: IntrinsicMeasurable, width: Int): Int {
        val constraints = targetConstraints
        return if (constraints.hasFixedHeight) constraints.maxHeight else constraints.constrainHeight(measurable.maxIntrinsicHeight(width))
    }
}

@Composable
private fun RefreshIndicator(
    pullToRefreshState: PullToRefreshState,
    circleSize: Dp,
    color: Color,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        // Only create rotation animation when actually refreshing to save resources
        val rotationState = if (pullToRefreshState.refreshState == RefreshState.Refreshing) {
            animateRotation()
        } else {
            null
        }
        Canvas(modifier = Modifier.size(circleSize)) {
            val ringStrokeWidthPx = circleSize.toPx() / 11
            val indicatorRadiusPx = max(size.minDimension / 2, circleSize.toPx() / 3.5f)
            val center = Offset(circleSize.toPx() / 2, circleSize.toPx() / 1.8f)

            when (pullToRefreshState.refreshState) {
                RefreshState.Idle -> return@Canvas

                RefreshState.Pulling -> {
                    if (pullToRefreshState.dragOffset > pullToRefreshState.refreshThresholdOffset) {
                        drawThresholdIndicator(
                            center,
                            indicatorRadiusPx,
                            ringStrokeWidthPx,
                            color,
                            pullToRefreshState.dragOffset,
                            pullToRefreshState.refreshThresholdOffset,
                            pullToRefreshState.maxDragDistancePx,
                        )
                    } else {
                        val alpha = (pullToRefreshState.visualProgress - 0.2f).coerceAtLeast(0f)
                        drawPullingIndicator(center, indicatorRadiusPx, ringStrokeWidthPx, color, alpha)
                    }
                }

                RefreshState.ThresholdReached -> {
                    drawThresholdIndicator(
                        center,
                        indicatorRadiusPx,
                        ringStrokeWidthPx,
                        color,
                        pullToRefreshState.dragOffset,
                        pullToRefreshState.refreshThresholdOffset,
                        pullToRefreshState.maxDragDistancePx,
                    )
                }

                RefreshState.Refreshing -> {
                    // Same masking window as Pulling; exactly 1 when entered from a gesture.
                    val expansionAlpha = ((pullToRefreshState.visualProgress - 0.2f) / 0.8f).coerceIn(0f, 1f)
                    drawRefreshingIndicator(
                        center,
                        indicatorRadiusPx,
                        ringStrokeWidthPx,
                        color.copy(alpha = color.alpha * expansionAlpha),
                        rotationState?.value ?: 0f,
                    )
                }

                RefreshState.RefreshComplete -> {
                    drawRefreshCompleteIndicator(
                        center,
                        indicatorRadiusPx,
                        ringStrokeWidthPx,
                        color,
                        pullToRefreshState.refreshCompleteAnimProgress,
                    )
                }
            }
        }
    }
}

@Composable
private fun animateRotation(): State<Float> {
    val infiniteTransition = rememberInfiniteTransition()
    val initialRotation = remember { (0..360).random().toFloat() }
    return infiniteTransition.animateFloat(
        initialValue = initialRotation,
        targetValue = initialRotation + 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
    )
}

private fun DrawScope.drawPullingIndicator(
    center: Offset,
    radius: Float,
    strokeWidth: Float,
    color: Color,
    alpha: Float,
) {
    drawCircle(
        color = color.copy(alpha = alpha),
        radius = radius,
        center = center,
        style = Stroke(strokeWidth, cap = StrokeCap.Round),
    )
}

private fun DrawScope.drawThresholdIndicator(
    center: Offset,
    radius: Float,
    strokeWidth: Float,
    color: Color,
    dragOffset: Float,
    thresholdOffset: Float,
    maxDrag: Float,
) {
    val lineLength = (dragOffset - thresholdOffset).coerceIn(0f, maxDrag - thresholdOffset)
    val topY = center.y
    val bottomY = center.y + lineLength
    drawArc(
        color = color,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = false,
        topLeft = Offset(center.x - radius, topY - radius),
        size = Size(radius * 2, radius * 2),
        style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
    )
    drawArc(
        color = color,
        startAngle = 0f,
        sweepAngle = 180f,
        useCenter = false,
        topLeft = Offset(center.x - radius, bottomY - radius),
        size = Size(radius * 2, radius * 2),
        style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
    )
    drawLine(
        color = color,
        start = Offset(center.x - radius, topY),
        end = Offset(center.x - radius, bottomY),
        strokeWidth = strokeWidth,
        cap = StrokeCap.Round,
    )
    drawLine(
        color = color,
        start = Offset(center.x + radius, topY),
        end = Offset(center.x + radius, bottomY),
        strokeWidth = strokeWidth,
        cap = StrokeCap.Round,
    )
}

private fun DrawScope.drawRefreshingIndicator(
    center: Offset,
    radius: Float,
    strokeWidth: Float,
    color: Color,
    rotation: Float,
) {
    drawCircle(
        color = color,
        radius = radius,
        center = center,
        style = Stroke(strokeWidth, cap = StrokeCap.Round),
    )
    val orbitRadius = radius - 2 * strokeWidth
    val angle = rotation * PI / 180.0
    val dotCenter = center + Offset(
        x = (orbitRadius * cos(angle)).toFloat(),
        y = (orbitRadius * sin(angle)).toFloat(),
    )
    drawCircle(color = color, radius = strokeWidth, center = dotCenter)
}

private fun DrawScope.drawRefreshCompleteIndicator(
    center: Offset,
    radius: Float,
    strokeWidth: Float,
    color: Color,
    progress: Float,
) {
    val animatedRadius = radius * (1f - progress).coerceAtLeast(0.9f)
    val alphaColor = color.copy(alpha = (1f - progress - 0.35f).coerceAtLeast(0f))
    val y = center.y - radius - strokeWidth + animatedRadius
    drawCircle(
        color = alphaColor,
        radius = animatedRadius,
        center = Offset(center.x, y),
        style = Stroke(strokeWidth, cap = StrokeCap.Round),
    )
}

private const val MAX_DRAWRATIO = 1 / 6f
private const val THRESHOLD_RADIO = 1 / 4f

internal val LocalPullToRefreshState = staticCompositionLocalOf<PullToRefreshState?> { null }

/** Default values for the [PullToRefresh] component. */
object PullToRefreshDefaults {
    val color: Color = Color.Gray
    val circleSize: Dp = 20.dp
    val refreshTexts = listOf(
        "Pull down to refresh",
        "Release to refresh",
        "Refreshing...",
        "Refreshed successfully",
    )
    val refreshTextStyle = TextStyle(
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold,
        color = color,
    )
}
