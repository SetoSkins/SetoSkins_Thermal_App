// Copyright 2026, compose-miuix-ui contributors
// SPDX-License-Identifier: Apache-2.0

package top.yukonga.miuix.kmp.glass

import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import top.yukonga.miuix.kmp.blur.Backdrop
import top.yukonga.miuix.kmp.glass.internal.ScrimBackdrop
import top.yukonga.miuix.kmp.layout.BottomSheetSurfaceScope
import top.yukonga.miuix.kmp.material.EdgeStroke
import top.yukonga.miuix.kmp.material.GlassEdgeStrokes
import top.yukonga.miuix.kmp.material.GlassMaterial
import top.yukonga.miuix.kmp.material.GlassMaterials
import top.yukonga.miuix.kmp.material.GlassShape
import top.yukonga.miuix.kmp.material.isRuntimeShaderSupported
import top.yukonga.miuix.kmp.theme.MiuixTheme

/** Default values for [GlassBottomSheet] and [glassBottomSheetSurface]. */
object GlassBottomSheetDefaults {
    val ScrimColor: Color = GlassDialogDefaults.ScrimColor

    /** Bottom-sheet material for the current theme. */
    @Composable
    fun material(): GlassMaterial = GlassMaterials.dialogGlass(
        isDark = MiuixTheme.colorScheme.background.luminance() < 0.5f,
    )

    /** Bottom-sheet bloom stroke for the current theme. */
    @Composable
    fun stroke(): EdgeStroke = GlassEdgeStrokes.forTheme(
        isDark = MiuixTheme.colorScheme.background.luminance() < 0.5f,
        light = GlassEdgeStrokes.MiddleLight,
        dark = GlassEdgeStrokes.MiddleDark,
    )

    /** Opaque fallback when no scene or runtime shader support is available. */
    @Composable
    fun containerColor(): Color = MiuixTheme.colorScheme.background
}

/**
 * A glass surface for OverlayBottomSheet's `surface` slot, with rounded top corners.
 *
 * The backdrop is dimmed before blur and sampled in the sheet's translated screen coordinates.
 * Upward overscroll extends the material without a stroke. Content is not refracted, and no
 * additional drop shadow is drawn.
 *
 * @param backdrop Page recording including bars, excluding the sheet host and its scrim.
 *   Null or unavailable runtime shaders use the opaque [containerColor] fallback.
 * @param material Shared dialog/sheet blur and ordered blend layers.
 * @param stroke Optional bloom stroke, omitted on the overscroll extension.
 * @param containerColor Opaque fallback fill.
 */
@Composable
fun glassBottomSheetSurface(
    backdrop: Backdrop?,
    material: GlassMaterial = GlassBottomSheetDefaults.material(),
    stroke: EdgeStroke? = GlassBottomSheetDefaults.stroke(),
    containerColor: Color = GlassBottomSheetDefaults.containerColor(),
): @Composable BottomSheetSurfaceScope.() -> Modifier = {
    val effectiveBackdrop = if (backdrop != null && isRuntimeShaderSupported()) {
        remember(backdrop, scrimColor) { ScrimBackdrop(backdrop, scrimColor) }
    } else {
        null
    }
    val shape = remember(cornerRadius) {
        GlassShape(topStart = cornerRadius, topEnd = cornerRadius, bottomEnd = 0.dp, bottomStart = 0.dp)
    }
    Modifier.glassPanel(
        backdrop = effectiveBackdrop,
        shape = shape,
        material = material,
        stroke = if (isOverscroll) null else stroke,
        shadow = null,
        shading = false,
        fallback = Modifier.clip(shape).background(containerColor),
    )
}
