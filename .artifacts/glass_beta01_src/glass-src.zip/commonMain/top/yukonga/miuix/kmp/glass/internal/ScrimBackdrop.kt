// Copyright 2026, compose-miuix-ui contributors
// SPDX-License-Identifier: Apache-2.0

package top.yukonga.miuix.kmp.glass.internal

import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.unit.Density
import top.yukonga.miuix.kmp.blur.Backdrop
import top.yukonga.miuix.kmp.blur.BackdropEffectScope

/** Applies a scrim to the padded backdrop recording before blur. */
@Stable
internal class ScrimBackdrop(
    private val backdrop: Backdrop,
    private val scrimColor: State<Color>,
    private val scale: State<Float>? = null,
) : Backdrop by backdrop {

    // Reused: recordings without a layerBlock must not allocate one per frame.
    private val scaleOnlyLayerBlock: GraphicsLayerScope.() -> Unit = {
        scale?.let {
            // The host already applies this scale. Only invert it during sampling.
            scaleX *= it.value
            scaleY *= it.value
        }
    }

    override fun DrawScope.drawBackdrop(
        density: Density,
        coordinates: LayoutCoordinates?,
        layerBlock: (GraphicsLayerScope.() -> Unit)?,
        downscaleFactor: Float,
    ) {
        with(backdrop) {
            drawBackdrop(
                density = density,
                coordinates = coordinates,
                layerBlock = when {
                    scale == null -> layerBlock

                    layerBlock == null -> scaleOnlyLayerBlock

                    else -> {
                        {
                            layerBlock.invoke(this)
                            scaleOnlyLayerBlock.invoke(this)
                        }
                    }
                },
                downscaleFactor = downscaleFactor,
            )
        }
        val color = scrimColor.value
        if (color.alpha > 0f) {
            val padding = (density as? BackdropEffectScope)?.padding ?: 0f
            // Exact padding: the recording offsets by `padding / level`, so rounding leaves a strip.
            val scaledPadding = padding / downscaleFactor
            // Cover recording padding; SrcAtop preserves transparent scene pixels to prevent halos.
            drawRect(color, topLeft = Offset(-scaledPadding, -scaledPadding), size = size, blendMode = BlendMode.SrcAtop)
        }
    }
}
