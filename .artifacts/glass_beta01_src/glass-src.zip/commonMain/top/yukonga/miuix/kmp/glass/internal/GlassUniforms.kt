// Copyright 2026, compose-miuix-ui contributors
// SPDX-License-Identifier: Apache-2.0

package top.yukonga.miuix.kmp.glass.internal

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.isSpecified
import top.yukonga.miuix.kmp.blur.BackdropEffectScope
import top.yukonga.miuix.kmp.blur.runtimeShaderEffect
import top.yukonga.miuix.kmp.material.GlassColorBlendMode
import top.yukonga.miuix.kmp.material.GlassColorLayer
import top.yukonga.miuix.kmp.material.GlassDefaults
import top.yukonga.miuix.kmp.material.GlassMaterial
import top.yukonga.miuix.kmp.material.GlassShape
import top.yukonga.miuix.kmp.material.GlassStyle
import top.yukonga.miuix.kmp.material.RuntimeShader
import top.yukonga.miuix.kmp.material.setSilhouetteUniforms
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min

/**
 * Adds the glass material to the backdrop effect pipeline.
 *
 * @param style Glass style.
 * @param shape Surface shape.
 * @param alpha Material opacity multiplier.
 * @param tint Optional tint override; its alpha replaces the style's tint strength.
 */
internal fun BackdropEffectScope.glassEffect(
    style: GlassStyle,
    shape: GlassShape,
    alpha: Float,
    tint: Color,
) {
    val width = size.width
    val height = size.height
    if (width <= 0f || height <= 0f) return

    val scale = downscaleFactor
    val paddedWidth = width + padding * 2f
    val paddedHeight = height + padding * 2f
    val textureWidth = (paddedWidth / downscaleFactor).coerceAtLeast(1f)
    val textureHeight = (paddedHeight / downscaleFactor).coerceAtLeast(1f)

    val sourceScale = density / GlassDefaults.SourceDensity
    val edgeFullPx = (style.edge.width * sourceScale).coerceAtLeast(1f)
    val tintColor = if (tint.isSpecified) tint else style.inner.tint
    val tintStrength = if (tint.isSpecified) tint.alpha else style.inner.tintStrength

    val wideReach = style.blur.big * sourceScale / scale
    val wideRadiusX = min(wideReach, textureWidth * 0.5f)
    val wideRadiusY = min(wideReach, textureHeight * 0.5f)
    val wideCollapse = (wideReach / (max(width, height) * 0.5f / scale).coerceAtLeast(1f))
        .coerceIn(0f, 1f)

    runtimeShaderEffect(GLASS_SHADER_KEY, GLASS_SHADER, "child") {
        setSilhouetteUniforms(shape, layoutDirection, size, this@glassEffect, scale)
        setFloatUniform("in_pad", padding / scale, padding / scale)
        setFloatUniform("in_maxCoord", textureWidth - 0.5f, textureHeight - 0.5f)
        setFloatUniform(
            "in_alphaEdge",
            (style.inner.alpha * alpha).coerceIn(0f, 1f),
            edgeFullPx / scale,
            style.edge.thickness * sourceScale / scale,
            style.edge.reflectOffset * sourceScale / scale,
        )
        setFloatUniform(
            "in_iorRefl",
            style.refract.ior,
            style.reflect.strength,
            style.reflect.lighten,
            style.inner.colorPow,
        )
        setFloatUniform("in_tint", tintColor.red, tintColor.green, tintColor.blue, tintStrength)
        setFloatUniform(
            "in_whiteMixBg",
            style.inner.colorWhite,
            style.inner.colorMix,
            style.background.saturation,
            style.background.brightness,
        )
        setFloatUniform(
            "in_darker",
            style.blend.darkerStart,
            style.blend.darkerEnd,
            style.blend.darker,
            style.inner.bottom,
        )
        setFloatUniform(
            "in_lightDir",
            style.light.directionX,
            style.light.directionY,
            style.light.directionZ,
            style.light.angleRange * PI.toFloat(),
        )
        setFloatUniform(
            "in_lightAmt",
            style.light.intensity,
            style.light.oppositeIntensity,
            style.blend.amount,
            GlassDefaults.Overspill * density / scale,
        )
        setFloatUniform(
            "in_lumCurve",
            style.blend.curveA,
            style.blend.curveB,
            style.blend.curveC,
            style.blend.curveD,
        )
        setFloatUniform(
            "in_satBri",
            style.blend.saturation,
            style.blend.brightness,
            style.background.burn,
            style.background.unShade.coerceIn(0f, 1f),
        )
        setFloatUniform(
            "in_edgePow",
            style.edge.pow.coerceAtLeast(0.01f),
            wideRadiusX,
            wideRadiusY,
            wideCollapse,
        )
    }
}

/**
 * Adds color blending to the backdrop effect pipeline.
 *
 * @param material Ordered color layers, nearest the backdrop first.
 * @param alpha Opacity multiplier for each layer.
 */
internal fun BackdropEffectScope.colorBlendEffect(
    material: GlassMaterial,
    alpha: Float,
    key: String = GLASS_COLOR_BLEND_SHADER_KEY,
) {
    val first = material.first
    val second = material.second
    val third = material.third
    val count = 1 + (if (second != null) 1 else 0) + (if (third != null) 1 else 0)
    val surfaceAlpha = alpha.coerceIn(0f, 1f)
    runtimeShaderEffect(key, GLASS_COLOR_BLEND_SHADER, "child") {
        setFloatUniform("in_blend0", first.color.red, first.color.green, first.color.blue, first.color.alpha * surfaceAlpha)
        setLayerUniform(1, second, surfaceAlpha)
        setLayerUniform(2, third, surfaceAlpha)
        setFloatUniform(
            "in_blendMode",
            first.mode.id,
            second?.mode?.id ?: 0f,
            third?.mode?.id ?: 0f,
            count.toFloat(),
        )
    }
}

/** Writes one optional colour layer, or clears the slot when [layer] is absent. */
private fun RuntimeShader.setLayerUniform(index: Int, layer: GlassColorLayer?, surfaceAlpha: Float) {
    if (layer == null) {
        setFloatUniform("in_blend$index", 0f, 0f, 0f, 0f)
    } else {
        setFloatUniform("in_blend$index", layer.color.red, layer.color.green, layer.color.blue, layer.color.alpha * surfaceAlpha)
    }
}

/** Blend-mode ID; must match the switch in `GLASS_COLOR_BLEND_SHADER`. */
private val GlassColorBlendMode.id: Float
    get() = when (this) {
        GlassColorBlendMode.SrcOver -> 0f
        GlassColorBlendMode.PlusDarker -> 1f
        GlassColorBlendMode.PlusLighter -> 2f
        GlassColorBlendMode.SoftLight -> 3f
        GlassColorBlendMode.HardLight -> 4f
        GlassColorBlendMode.Overlay -> 5f
        GlassColorBlendMode.Luminosity -> 6f
        GlassColorBlendMode.ColorDodge -> 7f
        GlassColorBlendMode.ColorBurn -> 8f
    }
